# PCCM+ OEM Launcher v0.7.4

Android launcher styled after the Porsche PCCM+ interface.

## v0.7.4 changes

- Replaced the Navigation icon with a combined Android Auto / Apple CarPlay icon.
- Renamed the `Nav` tile to `Phone Link`.
- Preserved the exact v0.7.3 layout, icon-view dimensions, spacing, label sizing, and launcher behavior.
- No other functional or visual changes.

## Build

Open the project root in Android Studio, allow Gradle to sync, then use:

`Build > Build Bundle(s) / APK(s) > Build APK(s)`

The debug APK is normally created at:

`app/build/outputs/apk/debug/app-debug.apk`
